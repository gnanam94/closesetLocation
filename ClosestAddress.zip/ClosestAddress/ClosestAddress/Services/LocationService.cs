﻿using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace ClosestAddress.Services
{
    public class LocationService
    {

        public List<place> getLocations(double lat, double lng)
        {
            List<place> placesModel = new List<place>();
            using (var db = new locationEntities1())
            {
                    var coord = new GeoCoordinate(lat, lng);
                    var nearest = db.places.AsEnumerable().Select(x => new GeoCoordinate(Convert.ToDouble(x.lat), Convert.ToDouble(x.longtitude)))
                         .OrderBy(x => x.GetDistanceTo(coord))
                         .Take(5);
                foreach(var near in nearest)
                {
                    place placeModel = db.places.AsEnumerable().Where(x => Convert.ToDouble(x.longtitude) == near.Longitude && Convert.ToDouble(x.lat) == near.Latitude).First();
                    placesModel.Add(placeModel);
                }
                
                return placesModel;
            }
        }
    }
}