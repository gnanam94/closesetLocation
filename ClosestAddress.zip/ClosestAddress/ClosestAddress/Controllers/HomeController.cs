﻿using ClosestAddress.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace ClosestAddress.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult Locations(string lat,string lng)
        {
            LocationService locationService = new LocationService();
            List<place>places=locationService.getLocations(Convert.ToDouble(lat), Convert.ToDouble(lng));
            return Json(places, JsonRequestBehavior.AllowGet);
        }
    }
    
}